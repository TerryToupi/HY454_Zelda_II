#include "Wosu.h"

Wosu::Wosu() {
	setHealth(8);
	setDamage(10);
	setPoints(0);
}

