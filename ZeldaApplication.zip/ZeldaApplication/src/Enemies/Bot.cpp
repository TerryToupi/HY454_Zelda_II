#include "Bot.h"

Bot::Bot() {
	setHealth(16);
	setDamage(15);
	setPoints(10);
}

void Bot::jump() {

}
