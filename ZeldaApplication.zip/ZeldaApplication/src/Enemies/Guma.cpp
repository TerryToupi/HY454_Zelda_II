#include "Guma.h"

Guma::Guma() {
	setHealth(50);
	setDamage(20);
	setPoints(64);

	//m_sheet = new AnimationSheet("guma_sheet", "Assets/")
}

void Guma::throwObject() {
}
