#ifndef WOSU_HPP
#define WOSU_HPP

#include "Enemy.h"

class Wosu : public Enemy {
public:
	Wosu();
	~Wosu() = default;
};

#endif 
