#include "Staflos.h"

Staflos::Staflos(){
	setHealth(32);
	setDamage(10);
	setPoints(30);
}

void Staflos::apearFromCeiling() {
}
